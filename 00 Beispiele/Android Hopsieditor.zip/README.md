# HopsiEditor
## Kompilieren
```bash
./gradlew createDistributable
```
Die kompilierte Version befindet sich dann im Ordner `build/compose/binaries/main/app/*/` und kann mit `./HopsiEditor` ausgeführt werden.
## Ausführen
```bash 
./gradlew run
```
