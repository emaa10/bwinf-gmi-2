import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject

fun calculateHops(text: String, startIndex: Int): Int { // Berechnet die Hops
  val chars = "abcdefghijklmnopqrstuvwxyzäöüß" // Erlaubte Zeichen
  var hops = 0 // Anzahl der Hops
  var x = startIndex // Enthält die aktuelle Position
  var pendingJump = 0 // Enthält die Anzahl der noch auszuführenden Hops
  if (x >= text.length) { // Wenn der Startindex außerhalb des Textes liegt
    return 0 // 0 Hops zurückgeben
  }
  var char = text[x].lowercaseChar() // Ersten Buchstaben holen
  while (true) {
    try {
      pendingJump = chars.indexOf(char) + 1 // Anzahl der Hops berechnen
      if (pendingJump > 0) { // Wenn ein Hop ausgeführt wird
        hops += 1 // Hop zählen
      }
      while (true) { // Solange bis der Text zuende ist
        if (text[x].lowercaseChar() !in chars) { // Wenn kein gültiger Buchstabe
          x += 1 // Weitergehen
        } else if (pendingJump > 0) { // Wenn noch Hops auszuführen sind
          x += 1 // Weitergehen
          pendingJump -= 1 // Hop ausführen
        } else { // Wenn kein Hop mehr auszuführen ist
          break // Abbrechen
        }
      }
      char = text[x].lowercaseChar() // Nächsten Buchstaben holen
    } catch (e: Exception) { // Wenn der Text zuende ist
      break // Abbrechen
    }
  }
  return hops // Anzahl der Hops zurückgeben
}

data class HopCharacter(val char: Char, var hoppedOn: Boolean = false) // Klasse für einen Buchstaben

fun hopAndReturn(text: String, startIndex: Int): List<HopCharacter> { // Hops ausführen und zurückgeben
  val hopList = mutableListOf<Int>(startIndex) // Liste der Hops
  val chars = "abcdefghijklmnopqrstuvwxyzäöüß"
  var x = startIndex
  var pendingJump = 0
  if (x >= text.length) {
    return listOf()
  }
  var char = text[x].lowercaseChar()
  while (true) {
    try {
      pendingJump = chars.indexOf(char) + 1
      hopList.add(x) // Hinzufügen der Position
      while (true) {
        if (text[x].lowercaseChar() !in chars) {
          x += 1
        } else if (pendingJump > 0) {
          x += 1
          pendingJump -= 1
        } else {
          break
        }
      }
      char = text[x].lowercaseChar()
    } catch (e: Exception) {
      break
    }
  }
  return text.mapIndexed { index, c -> // Liste der Buchstaben zurückgeben
    HopCharacter(c, index in hopList) // Wenn die Position in der Liste ist, wurde gehoppt
  }
}

fun completeText(text: String): String? { // Text mit Chungus Ask API vervollständigen
  // Prompt der den Text vervollständigt
  val question = "Füge dem Text 1-2 passende Sätze hinzu. Antworte mit dem geänderten Text. " +
          "Gebe keine Informationen über dich zurück. Vervollständige nur den Text." +
          "Füge keine anderen Zeichen, Einleitungen oder Anhänge hinzu. Antworte nur mit dem geänderten Text." +
          "Text: \n$text"

  val client = OkHttpClient() // HTTP Client erstellen
  val requestBody = MultipartBody.Builder()
    .setType(MultipartBody.FORM)
    .addFormDataPart("question", question) // Frage hinzufügen
    .addFormDataPart("temperature", "0.65") // Temperatur hinzufügen
    .build()

  val url = "https://chungusai.com/api/free/ask" // URL der API

  val request = Request.Builder() // Request erstellen
    .url(url)
    .post(requestBody)
    .build()

  val response = client.newCall(request).execute() // Request ausführen
  val responseBody = response.body?.string() // Antwort holen
  print(responseBody) // Antwort ausgeben

  // JSON parsen
  val json = JSONObject(responseBody) // JSON Objekt erstellen
  if (json.has("error")) { // Wenn ein Fehler aufgetreten ist
    println("Error: ${json.getString("error")}") // Fehler ausgeben
    throw Exception("Error: ${json.getString("error")}") // Fehler werfen
  } else {
    var answer = json.getString("message").replace("  ", " "); // Antwort holen und doppelte Leerzeichen entfernen
    answer = answer.trim() // Leerzeichen am Anfang und Ende entfernen
    println("Antwort: $answer") // Antwort ausgeben
    return answer // Antwort zurückgeben
  }
}
