import androidx.compose.desktop.ui.tooling.preview.Preview
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.ClipboardManager
import androidx.compose.ui.text.*
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application

import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.window.Dialog
import java.awt.Dialog
import java.awt.TextField
import javax.swing.JOptionPane

@Composable
fun Toolbar(text: String, onTextChange: (String) -> Unit) { // Toolbar
  val clipboardManager = LocalClipboardManager.current // Zwischenablage
  var loading by remember { mutableStateOf(false) } // Ladezustand
  TopAppBar( // Obere Leiste
    title = { Text("HopsiEditor", fontSize = 20.sp) }, // Titel
    actions = { // Aktionsleiste
      IconButton(onClick = { // Kopieren
        clipboardManager.setText(AnnotatedString(text))
      }) {
        Icon(Icons.Default.ContentCopy, contentDescription = "Copy") // Icon
      }
      if (loading) {
        Button(onClick = {}) { // Ladekreis
          CircularProgressIndicator(Modifier.size(24.dp), color = MaterialTheme.colors.onPrimary)
        }
      } else {
        Button(onClick = {
          // Text Vervollständigung in seperatem Thread
          Thread {
            loading = true
            if (text.isEmpty()) { // Fehlermeldung bei leerem Text
              JOptionPane.showMessageDialog(
                null,
                "Bitte gebe einen Text ein",
                "Fehler",
                JOptionPane.ERROR_MESSAGE
              )
              loading = false
              return@Thread
            }
            try {
              val newText = completeText(text)!! // Vervollständigten Text holen
              onTextChange(newText) // Text setzen
            } catch (e: Exception) { // Fehlermeldung bei Fehler
              println("Fehler: $e")
              JOptionPane.showMessageDialog(
                null, "Fehler: $e", "Fehler",
                JOptionPane.ERROR_MESSAGE
              )
            }
            loading = false
          }.start() // Starten des Threads
        }) {
          Text("Vervollständigen") // Text
        }
      }
    },
    backgroundColor = MaterialTheme.colors.surface,
    contentColor = MaterialTheme.colors.onSurface,
    elevation = 4.dp
  )
}

@Composable
fun BottomStatusBar(player1Hops: Int, player2Hops: Int) { // Statusleiste
  BottomAppBar(
    backgroundColor = MaterialTheme.colors.surface,
    contentColor = MaterialTheme.colors.onSurface,
    elevation = 4.dp,
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(4.dp),
      horizontalArrangement = Arrangement.SpaceBetween
    ) {
      Text("Sprünge Spieler 1: $player1Hops") // Anzeige der Sprünge
      Text("Sprünge Spieler 2: $player2Hops")
      if (player1Hops == player2Hops) { // Anzeige des Gewinners
        Text("Unentschieden!")
      } else {
        Text("Gewinner: Spieler ${if (player1Hops > player2Hops) 1 else 2}")
      }
    }
  }
}

@Composable
@Preview
fun App() {
  var text by remember { mutableStateOf("") } // Enthält den Text

  MaterialTheme { // Material Design Standarttheme
    Scaffold(
      topBar = { Toolbar(text, onTextChange = { text = it }) } // Toolbar
    ) {
      Column(
        modifier = Modifier
          .fillMaxSize()
      ) {
        Divider(color = Color.Black, thickness = 1.dp)
        TextField( // Textfeld für den Text
          value = text, // Wert des Textfeldes
          placeholder = { Text("Text eingeben") }, // Platzhalter
          colors = TextFieldDefaults.textFieldColors( // Entfernen der Dekoration
            backgroundColor = Color.Transparent,
            focusedIndicatorColor = Color.Transparent,
            unfocusedIndicatorColor = Color.Transparent,
            disabledIndicatorColor = Color.Transparent
          ),
          onValueChange = { text = it }, // Änderung des Textes möglich machen
          modifier = Modifier // Ausfüllen des Bildschirms
            .fillMaxWidth()
            .weight(1f)
            .padding(8.dp)
            .background(Color.White),
          textStyle = TextStyle( // Textstil
            color = Color.Black,
            fontSize = 16.sp
          ),
          singleLine = false, // Mehrzeiliges Textfeld
          visualTransformation = { // Highlighting der Sprünge
            TransformedText(
              buildAnnotatedString {
                val hopCharacters = hopAndReturn(text, 0) // Sprünge Spieler 1
                val hopCharacters2 = hopAndReturn(text, 1) // Sprünge Spieler 2
                // Iteration über den Text
                text.forEachIndexed { index, c ->
                  val hopCharacter = hopCharacters.getOrNull(index) // Sprung des Spielers 1
                  val hopCharacter2 = hopCharacters2.getOrNull(index) // Sprung des Spielers 2
                  val color = when { // Farbe des Textes
                    hopCharacter?.hoppedOn == true && hopCharacter2?.hoppedOn == true -> Color.Green
                      // Grün bei Überschneidung
                    hopCharacter?.hoppedOn == true -> Color.Red // Rot bei Sprung des Spielers 1
                    hopCharacter2?.hoppedOn == true -> Color.Blue // Blau bei Sprung des Spielers 2
                    else -> Color.Black // Schwarz bei keinem Sprung
                  }
                  withStyle(style = SpanStyle(color = color)) { // Setzen der Farbe
                    append(c.toString())
                  }
                }
              },
              offsetMapping = OffsetMapping.Identity // Keine Verschiebung
            )
          }
        )
        Divider(color = Color.Black, thickness = 1.dp) // Trennlinie
        BottomStatusBar(calculateHops(text, 0), calculateHops(text, 1)) // Statusleiste
      }
    }
  }
}

fun main() = application {
  Window(onCloseRequest = ::exitApplication, title = "HopsiEditor", icon = painterResource("icon.png")) {
    App() // Starten der App
  }
}