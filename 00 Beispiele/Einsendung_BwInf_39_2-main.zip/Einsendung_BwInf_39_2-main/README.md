# Einsendung zur 2. Runde des 39. Bundeswettbewerbs Informatik (BwInf)
